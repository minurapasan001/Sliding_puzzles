import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

public class Main {
    // The `main` method is called when the program is executed.
    public static void main(String[] args) throws FileNotFoundException {

        // Input file path
        String fileLocation = "src/";    // file path
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter file path : ");    // input path location name
        String fileName = scanner.nextLine();

        File algo = new File(fileLocation+fileName);   // conform the correct path
//        Scanner reade = new Scanner(algo);

        // Create a new path to the graph file.
        AdjacencyListGraph graph = GraphFileParser.pase(String.valueOf(algo));

        // Print the number of vertices in the graph
        System.out.println("Number of Vertices : " + graph.getNumVertices());

        // Get the list of edges in the graph
        List<List<Integer>> edgelist = graph.getEdges();

        // Print the edges if there are any, otherwise print a message indicating no edges exist.
        if (edgelist.isEmpty()){
            System.out.println("The graph contains no edges\n");
        } else {
            System.out.println(" Edges are : " + graph.getEdges() + "\n");
        }

        // Print the adjacency list of the graph if it is not empty.
        String adjacency = graph.AdjacencyList();
        if (adjacency.isEmpty()){
            System.out.println("Empty list   ");
        } else {
            System.out.println("Adjacency List : \n" + graph.AdjacencyList());
        }

        // Check if the graph is acyclic or cyclic and print the result.
        if (graph.getNumVertices() == 0) {
            System.out.println("The graph is empty, Cannot identify the graph is 'Cyclic' or the 'Acyclic'");
        } else {
            if (AcyclicEncounter.isCyclicGraph(graph))
                System.out.println("\nGraph is Acyclic ");
            else
                System.out.println("\nGraph is cyclic  ");
        }
    }
}
