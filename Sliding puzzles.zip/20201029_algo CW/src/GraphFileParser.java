import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GraphFileParser
{
   //graph from a file and returns it as an AdjacencyListGraph object.
    public static AdjacencyListGraph pase(String filename) throws FileNotFoundException
    {
        // Create a new AdjacencyListGraph object to store the graph.
        AdjacencyListGraph graph = new AdjacencyListGraph();
        Scanner scanner = new Scanner(new File(filename));

        // Read in each line of the file.
        while (scanner.hasNextLine())
        {
            // Get the next line of the file.
            String lines = scanner.nextLine();

            // Split the line into two nodes.
            String[] nodes = lines.split(" ");

            // If the line doesn't contain two nodes, skip it.
            if (nodes.length != 2)
            {
                continue;
            }

            // Parse the nodes as integers.
            int from = Integer.parseInt(nodes[0]);
            int to = Integer.parseInt(nodes[1]);

            // Add an edge between the two nodes to the graph.
            graph.addEdge(from, to);
        }
        System.out.println();
       // Close the scanner.
        scanner.close();

        return graph;
    }
}