import java.util.*;

public class AdjacencyListGraph
{
    // A HashMap that stores the adjacency list of the graph.
    private HashMap<Integer, ArrayList<Integer>> adjList;

    // constructor to create a directed graph object.
    public AdjacencyListGraph ()
    {
        // Initialize the adjacency list to an empty HashMap.
        adjList = new HashMap<>();
    }

    public void addtex(int vertex)
    {
        // Check if the vertex is already in the graph
        if (!adjList.containsKey(vertex))
        // If not, add it to the graph with an empty list of neighbors
        {
            adjList.put(vertex, new ArrayList<>());
        }
    }
    // Add an edge between two vertices in the graph
    public void addEdge(int from, int to)
    {
        // Check if the edge is valid
        if (from != to)
        {
            // Add the vertices to the graph if they are not already in it
            addtex(from);
            addtex(to);
            // Add the neighbor to the adjacency list of the source vertex
            adjList.get(from).add(to);
        }else
        {
            // If the edge is not valid, print an error message
            System.out.println("The Edge specified  in the graphVertexAndEdge.txt From: "+ from + " To: " + to + " is not valid");
        }
    }
    // Remove a vertex from the graph
    public void removeVertex(int vertex)

    {// Remove the vertex from the adjacency list if it is in the graph
        if (adjList.containsKey(vertex))
        {
            adjList.remove(vertex);
        }
    }

    // Get the number of vertices in the graph
    public int getNumVertices() {return adjList.size();}

    // Get the neighbors of a vertex in the graph
    public List<Integer> getNeighbors(int vertex)
    {
        // Return the list of neighbors if the vertex is in the graph
        if (adjList.containsKey(vertex))
        {
            return adjList.get(vertex);
        }
        // Otherwise, return an empty list
        return new ArrayList<>();
    }


    // Get an array of all the vertices in the graph
    public int[] getVertices()
    {
        return adjList.keySet().stream().mapToInt(Integer::intValue).toArray();
    }

    // Get a list of all the edges in the graph
    public List<List<Integer>> getEdges()
    {
        List<List<Integer>> edges = new ArrayList<>();
        // Iterate through each vertex in the graph
        for (Map.Entry< Integer, ArrayList<Integer> > entry : adjList.entrySet())
        {
            int source = entry.getKey();
            List<Integer> neighbors = entry.getValue();
            // Iterate through each neighbor of the vertex
            for (int neighbor : neighbors)
            {
                // Add the edge to the list of edges
                edges.add(Arrays.asList(source, neighbor));
            }
        }
        return edges;
    }

    public String AdjacencyList()
    {
        StringBuilder ss = new StringBuilder();
        // Iterate through each vertex in the graph
        for (Map.Entry<Integer, ArrayList<Integer>> entry : adjList.entrySet())
        {
            Integer num = entry.getKey();
            ArrayList<Integer> neighbors = entry.getValue();
            // Append the vertex
            ss.append(num).append(": ");
            for (Integer neighbor : neighbors)
            {
                ss.append(neighbor).append("  ");
            }
            ss.append("\n");
        }
        return ss.toString();
    }
}