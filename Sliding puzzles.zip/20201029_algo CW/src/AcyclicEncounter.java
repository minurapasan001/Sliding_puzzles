import java.util.*;

public class AcyclicEncounter
{
    public static boolean isCyclicGraph(AdjacencyListGraph graph)
    {
        // A set to store the visited vertices.
        Set<Integer> visited = new HashSet<>();
        // A set to store the vertices that are currently being processed.
        Set<Integer> currentStack = new HashSet<>();
        // A list to store the vertices in a cycle.
        List<Integer> cycle = new ArrayList<>();

        // Iterate over all the vertices in the graph.
        for (int vertex : graph.getVertices())
        {
            // If the vertex has not been visited yet
            if (!visited.contains(vertex))
            {
                // Recursively check if the vertex is part of a cycle.
                if (detectCycleInGraphUsingDFS(vertex, visited, currentStack, graph, cycle))
                {
                    cycle.add(vertex);
                    Collections.reverse(cycle);
                    int startIndex = cycle.indexOf(cycle.get(cycle.size() - 1));
                    List<Integer> subCycle = cycle.subList(startIndex, cycle.size());
                    System.out.print("\nCycle detected: ");
                    for (int i = 0; i < subCycle.size(); i++)
                    {
                        System.out.print(subCycle.get(i));
                        if (i != subCycle.size() - 1)
                        {
                            System.out.print(" --> ");
                        }
                    }
                    // If the vertex is part of a cycle, return true.
                    System.out.println();
                    return false;
                }
            }
        }
        // If no cycle is found, return false.
        return true;
    }

    private static boolean detectCycleInGraphUsingDFS(int vertex, Set<Integer> visited, Set<Integer> currentStack, AdjacencyListGraph graph, List<Integer> cycle)
    {
        // Mark the vertex as visited.
        visited.add(vertex);
        // Add the vertex to the current stack.
        currentStack.add(vertex);
        System.out.println("Visiting vertex " + vertex + " (adding it to the visited set and current stack)");
        // Iterate over all the neighbors of the vertex.
        for (int neighbor : graph.getNeighbors(vertex))
        {
            // If the neighbor has not been visited yet,
            if (!visited.contains(neighbor))
            {
                System.out.println("  * Vertex " + neighbor + " If the vertex has not been visited yet, visit it recursively.\n");
                // Recursively check if the neighbor is part of a cycle.
                if (detectCycleInGraphUsingDFS(neighbor, visited, currentStack, graph, cycle))
                {
                    cycle.add(neighbor);
                    System.out.println("  * Detected cycle involving vertex " + neighbor + " (adding it to the cycle list)");
                    // If the neighbor is part of a cycle, return true.
                    return true;
                }
            }
            // If the neighbor is in the current stack
            else if (currentStack.contains(neighbor))
            {
                // A cycle is detected.
                cycle.add(neighbor);
                System.out.println("  * Detected cycle involving vertex " + neighbor + " (adding it to the cycle list)");
                return true;
            }
            else
            {
                System.out.println("  * Vertex " + neighbor + " is not currently in the stack.");
            }
        }
        // Remove the vertex from the current stack.
        currentStack.remove(vertex);
        System.out.println("Removing vertex " + vertex + " from the current stack");
        // No cycle is detected.
        return false;
    }
}
